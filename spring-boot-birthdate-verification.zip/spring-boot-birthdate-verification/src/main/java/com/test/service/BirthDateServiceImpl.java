package com.test.service;

import org.springframework.stereotype.Service;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import static java.util.Calendar.YEAR;
@Service
public class BirthDateServiceImpl {
    public String getMessage(String name, String birthDate) {
        return getMessageBasedOnBirthDate(name, birthDate);
    }

    public String getMessageBasedOnBirthDate(String name, String brithDate){
        boolean invalidBirthDate = isValidBirthDate(brithDate);
        String message = null;
        if(invalidBirthDate){
            System.out.println("Invalid date of birth");
            message = "Invalid date of birth";
        }
        Date currentDate = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy HH:mm");
        String currentDateString = formatter.format(currentDate);
        Date birthDateInDateFormat = null;

        try {
            birthDateInDateFormat = formatter.parse(brithDate);
            Calendar a = getCalendar(currentDate);
            Calendar b = getCalendar(birthDateInDateFormat);
            int age = a.get(YEAR) - b.get(YEAR);
            if(0!= age){
                if(age <18) {
                    if(null != name){
                        System.out.println("Welcome " + name + " Junior");
                        message = "Welcome " + name + " Junior";
                    }

                }
                else if(age > 18) {
                    if(null != name){
                        System.out.println("Welcome " + name + " Senior");
                        message = "Welcome " + name + " Senior";
                    }

                }
            }

        } catch (Exception e) {
            message = "Invalid date of birth";
        }
        return message;
    }

    public boolean isValidBirthDate(String brithDate) {
        DateFormat sdf = new SimpleDateFormat("MM/dd/yyyy HH:mm");
        boolean dateFormat = true;
        boolean invalidBirthDate = false;
        sdf.setLenient(false);
        try {
            sdf.parse(brithDate);
        } catch (ParseException e) {
            dateFormat = false;
        }
        try {
            Date birthDateInDateFormat = sdf.parse(brithDate);
            Date currentDate = new Date();
            if(birthDateInDateFormat.compareTo(currentDate) > 0 || !dateFormat){
                //System.out.println("Invalid date of birth");
                invalidBirthDate = true;
            }
        } catch (ParseException e) {
            invalidBirthDate = true;
        }
        return invalidBirthDate;
    }

    public Calendar getCalendar(Date date) {
        Calendar cal = Calendar.getInstance(Locale.US);
        cal.setTime(date);
        return cal;
    }

}

