package com.test.controller;

import com.test.model.BirthDateMessageResponse;
import com.test.service.BirthDateServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1")
public class BirthDateController {

    @Autowired
    BirthDateServiceImpl birthDateServiceImpl;

    public BirthDateController(BirthDateServiceImpl birthDateServiceImpl){
        this.birthDateServiceImpl = birthDateServiceImpl;
    }

    @GetMapping(produces = {"application/json"}, value = { "/GetBirthDateMessage" })
    public BirthDateMessageResponse getBirthDateMessage(@RequestParam(value = "name", required = true) String name,
                                                        @RequestParam(value = "birthdate", required = true) String birthdate) {

        String message = birthDateServiceImpl.getMessage(name, birthdate);
        BirthDateMessageResponse birthDateMessageResponse = new BirthDateMessageResponse();
        birthDateMessageResponse.setMessage(message);
        return birthDateMessageResponse;
    }

}