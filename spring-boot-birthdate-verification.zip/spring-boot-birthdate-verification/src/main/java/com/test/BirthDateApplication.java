package com.test;

import com.test.controller.BirthDateController;
import com.test.model.BirthDateMessageResponse;
import com.test.service.BirthDateServiceImpl;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackageClasses = {BirthDateController.class, BirthDateMessageResponse.class, BirthDateServiceImpl.class})
public class BirthDateApplication {
    public static void main(String[] args) {
        SpringApplication.run(BirthDateApplication.class, args);
    }
}
